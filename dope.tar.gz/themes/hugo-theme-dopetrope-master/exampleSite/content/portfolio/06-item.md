+++
description = "Portfolio item description"
thumbnail = "images/pic07.jpg"
image = "images/pic01.jpg"
title = "Portfolio item"
slug = "6-portfolio"
author = "John Smith"
draft = false
+++
Testing content